package com.item;

public enum ItemType {
    scut, vesta, sabiuta, bagheta, vitamine, brad, pelerina
}
