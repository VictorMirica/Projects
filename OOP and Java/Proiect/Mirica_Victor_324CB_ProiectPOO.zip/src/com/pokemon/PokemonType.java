package com.pokemon;

public enum PokemonType {
    neutrel1, neutrel2, pikachu, bulbasaur, charmander, squirtle,
    snorlax, vulpix, eevee, jigglypuff, meowth, psyduck
}
